import * as dashboardReducer from './dashboard.reducer';

export const dashboardsReducer = dashboardReducer.dashboardReducer;

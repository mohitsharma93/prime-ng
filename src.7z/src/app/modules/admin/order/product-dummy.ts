export const data = [
		{
			"id": "VSK2201",
			"name": "John Deo",
			"address": "201, sp building",
			"mobile": "1236547890",
			"order_amt": "50,000",
			"order_date": "04/01/2021",
			"status": "Pending"
		},
		{
			"id": "VSK2202",
			"name": "John Deo",
			"address": "201, sp building",
			"mobile": "1236547890",
			"order_amt": "50,000",
			"order_date": "04/01/2021",
			"status": "Accepted"
		},
		{
			"id": "VSK2203",
			"name": "John Deo",
			"address": "201, sp building",
			"mobile": "1236547890",
			"order_amt": "50,000",
			"order_date": "04/01/2021",
			"status": "Shipped"
		},
		{
			"id": "VSK2204",
			"name": "John Deo",
			"address": "201, sp building",
			"mobile": "1236547890",
			"order_amt": "50,000",
			"order_date": "04/01/2021",
			"status": "Delivered"
		},
		{
			"id": "VSK2205",
			"name": "John Deo",
			"address": "201, sp building",
			"mobile": "1236547890",
			"order_amt": "50,000",
			"order_date": "04/01/2021",
			"status": "Cancelled"
		},
		{
			"id": "VSK2206",
			"name": "John Deo",
			"address": "201, sp building",
			"mobile": "1236547890",
			"order_amt": "50,000",
			"order_date": "04/01/2021",
			"status": "Accepted"
		},
		{
			"id": "VSK2207",
			"name": "John Deo",
			"address": "201, sp building",
			"mobile": "1236547890",
			"order_amt": "50,000",
			"order_date": "04/01/2021",
			"status": "Cancelled"
		},
		{
			"id": "VSK2208",
			"name": "John Deo",
			"address": "201, sp building",
			"mobile": "1236547890",
			"order_amt": "50,000",
			"order_date": "04/01/2021",
			"status": "Shipped"
		},
		{
			"id": "VSK2209",
			"name": "John Deo",
			"address": "201, sp building",
			"mobile": "1236547890",
			"order_amt": "50,000",
			"order_date": "04/01/2021",
			"status": "Pending"
		},
		{
			"id": "VSK2210",
			"name": "John Deo",
			"address": "201, sp building",
			"mobile": "1236547890",
			"order_amt": "50,000",
			"order_date": "04/01/2021",
			"status": "Pending"
		}
	]
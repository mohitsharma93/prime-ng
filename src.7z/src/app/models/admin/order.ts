export interface IOrderRequestModel {
  endPoint: string,
  orderStatusId: number,
  urlMiddlePoint: string
}
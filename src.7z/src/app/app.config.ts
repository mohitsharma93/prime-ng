export const APP_CONFIG = {

    API: {

        AUTH: {
            LOGIN: 'auth/sign-in',
            FORGOT_PASSWORD: 'auth/forgotPassword',
            CHANGE_PASSWORD: 'api/sellerDashboard/sellerAuth/ChangePassword',
            SEND_OTP: 'api/sellerDashboard/sellerAuth/SendOtp',
            VERIFY_OTP: 'api/sellerDashboard/sellerAuth/VerfiyOtp',
        },

    }
}
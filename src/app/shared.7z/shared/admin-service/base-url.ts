export const createUrl = (baseUrl: string, url: string): string => {
  return `${baseUrl}/${url}`;
};

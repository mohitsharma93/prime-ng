export const environment = {
  production: true,
  // API_ENDPOINT: 'http://192.168.1.135:5252/',
  API_ENDPOINT:'http://192.168.1.101:7890/',
  API_ENDPOINT_PROXY: 'api/sellerDashboard/ShopOverview'
};

export const dummyData = [
  {
    SNo: 1, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 2, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 13, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 14, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 15, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 16, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 17, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 18, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 19, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 10, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 21, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 33, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 333, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 1331, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 123, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  {
    SNo: 12222, BuyerName: 'sdfasffff', OrderID: 23, NoOfItem: 333, OrderAmount: 1000, Status: 'Pending'
  },
  
]
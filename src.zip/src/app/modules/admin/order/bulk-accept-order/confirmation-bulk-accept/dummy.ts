export const dummyData = [
  {SNo: 1, ItemName: 'dj', Quantity: 12, OrderWiseQuantity: [ {1189: 90}, { 1180: 100}]},
  {SNo: 2, ItemName: 'fasf', Quantity: 12, OrderWiseQuantity: [ {1189: 90}, { 1180: 100}]},
  {SNo: 3, ItemName: 'd sfadf j', Quantity: 12, OrderWiseQuantity: [ {1189: 90}, { 1180: 100}]},
  {SNo: 4, ItemName: 'asefa', Quantity: 12, OrderWiseQuantity: [ {1189: 90}, { 1180: 100}]},
  {SNo: 5, ItemName: 'dfasdf j', Quantity: 12, OrderWiseQuantity: [ {1189: 90}, { 1180: 100}]},
  {SNo: 6, ItemName: 'asdfasdf', Quantity: 12, OrderWiseQuantity: [ {1189: 90}, { 1180: 100}]},
]
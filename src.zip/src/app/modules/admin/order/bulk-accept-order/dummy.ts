export const dummyData = [
  {
    SNo: 1, ItemName: 'sdfasffff', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 2, ItemName: 'sdfasfasdf', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 3, ItemName: 'sdfassre', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 4, ItemName: 'sdfasaer', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 5, ItemName: 'sdfasfdfgsdfg', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 56, ItemName: 'sdfasaerqw', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 6, ItemName: 'sdfas', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 7, ItemName: 'sdfas', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 8, ItemName: 'sdfas', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 18, ItemName: 'sdfas', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 18, ItemName: 'sdfas', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 18, ItemName: 'sdfas', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 188, ItemName: 'sdfas', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 19, ItemName: 'sdfas', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 19, ItemName: 'asdfasdf', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 10, ItemName: 'sdfsdfasdfas', NetQuantity: 23, Orders: 333, OrderAmount: 1066600
  },
  {
    SNo: 21, ItemName: 'sdfasdfasdfas', NetQuantity: 23, Orders: 3383, OrderAmount: 1000
  },
  {
    SNo: 22, ItemName: 'sdfdddas', NetQuantity: 283, Orders: 3833, OrderAmount: 1000
  },
  {
    SNo: 23, ItemName: 'ff', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 24, ItemName: 'dd', NetQuantity: 23, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 25, ItemName: 'dddd', NetQuantity: 283, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 126, ItemName: 'ddddd', NetQuantity: 723, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 1, ItemName: 'ddfasdf', NetQuantity: 623, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 122, ItemName: 'sdfaseravaas', NetQuantity: 233, Orders: 333, OrderAmount: 1000
  },
  {
    SNo: 222, ItemName: 'faergaf', NetQuantity: 523, Orders: 3323, OrderAmount: 233333
  },
  {
    SNo: 33, ItemName: 'sdgaerawer', NetQuantity: 23, Orders: 33, OrderAmount: 233333
  },
  {
    SNo: 333, ItemName: 'faerwaga', NetQuantity: 23, Orders: 233333, OrderAmount: 233333
  },
  {
    SNo: 3333, ItemName: 'faewarqwer', NetQuantity: 233, Orders: 233333, OrderAmount: 233333
  }
]
import * as dashboardReducer from './order.reducer';

export const ordersReducer = dashboardReducer.orderReducer;
